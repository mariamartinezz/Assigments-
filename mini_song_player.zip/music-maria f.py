#code
from playaudio import playaudio
import os

def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear") 

clear()
songs_path= os.listdir('songs')
songs = {}
show_text = f'''Welcome to Mini Song Player
Enter a number to play the song:
'''

for i, s in enumerate(songs_path):
    if s.endswith('.mp3'):
        songs[i+1] = s
        show_text = show_text + str(i+1)+'. '+str(s) + '\n'

show_text = show_text
print(show_text)

while True:
    try: 
        i = int(input())
        try:
            clear()
            print(f'Playing: {songs[i]}.\nEnjoy it!')
            playaudio(f'songs\\{songs[i]}')
            break
        except KeyError:
            print('Song not available')
    except ValueError:
        print('You need to enter a number.')